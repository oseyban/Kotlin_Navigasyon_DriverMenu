package com.os.kotlin_navigasyon.ui.gallery

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GalleryViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Bu bölüm Resim Galerisi dir."
    }
    val text: LiveData<String> = _text
}